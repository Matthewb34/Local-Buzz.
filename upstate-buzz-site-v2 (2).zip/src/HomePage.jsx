import { Card, CardContent } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Phone, Mail, Sparkles } from "lucide-react";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-neutral-100 to-yellow-50 p-6">
      <div className="max-w-5xl mx-auto">
        <header className="mb-16 text-center">
          <h1 className="text-5xl font-extrabold text-yellow-600 mb-4 drop-shadow-sm">Upstate Buzz</h1>
          <p className="text-2xl text-neutral-700 italic">
            Digital growth strategies by Matthew Barlow — specializing in service-based businesses.
          </p>
        </header>
        ...
      </div>
    </div>
  );
}