
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Phone, Mail, Sparkles } from "lucide-react";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-neutral-50 to-neutral-200 p-6">
      <div className="max-w-4xl mx-auto">
        <header className="mb-12 text-center">
          <h1 className="text-5xl font-bold text-neutral-900 mb-2">Upstate Buzz</h1>
          <p className="text-xl text-neutral-600">
            Digital growth strategies by Matthew Barlow — specializing in service-based businesses.
          </p>
        </header>

        <section className="mb-10">
          <Card className="rounded-2xl shadow-lg border border-neutral-300 bg-white">
            <CardContent className="p-8">
              <h2 className="text-4xl font-bold text-neutral-900 mb-4">About Me</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <img src="/images/IMG_1004.jpeg" alt="Matthew and wife on beach" className="rounded-xl w-full object-cover" />
                <img src="/images/IMG_1001.jpeg" alt="Piggyback beach photo" className="rounded-xl w-full object-cover" />
              </div>
              <p className="text-neutral-700 text-lg leading-relaxed">
                I’m Matthew Barlow, the guy behind Upstate Buzz. I run an electrical company, live with my wife and two dogs, and know what it’s like to run a hands-on business. I help service-based companies grow with personalized digital strategies. I’m not a big agency — just someone who genuinely cares about helping real people build their brand.
              </p>
              <div className="mt-6">
                <img src="/images/IMG_1482.jpeg" alt="Two black dogs smiling" className="rounded-xl w-full object-cover" />
              </div>
            </CardContent>
          </Card>
        </section>

        <!-- More sections here... (left out for brevity) -->
      </div>
    </div>
  );
}
